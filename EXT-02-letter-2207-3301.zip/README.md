# EXT-02 Letter Recognition 复算材料

两次运行采用固定执行提交 e5dfe764e4f65fb3336659d6cd52c05c3c64f52f，按 2207、3301 顺序完成。原种子 1103 的账本条目保留在同一个输出父目录的累计记录中。两次共完成 36 个目标模型条件，自动核算与再次独立复算均为 REPRODUCED。

配对差为来源符合性排序的测试 LogLoss 减去证据组的测试 LogLoss。两个种子是同一 UCI 来源的不同划分。公开许可、原始数据摘要、参与者应复算的文件清单分别见 source、inputs、checks 及 results。

正式运行前，Windows 虚拟环境启动器触发了一条子进程测试的父进程检查。用同一 Python 3.10.11 解释器直启并加载同一组固定依赖后，49 项测试全部通过。训练依照候选提交的原有监督器执行，提交、数据与训练协议无变更。

复算使用该提交的 scripts/external_experiments/verify.py，将 --result 指向对应运行的 worker_output，将 --config 和 --data-dir 指向对应种子的冻结输入。把 --output 指向归档外的新 JSON。
