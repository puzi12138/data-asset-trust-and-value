"""Independently check EXT-03 saved selections and recalculate regression metrics."""

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import random


COMMIT = "cfd73d1e5c84351348062b5c0fe8e4d7beebfb53"
MODEL_NAMES = ("ridge", "random_forest")
BUDGETS = (128, 512)
METHODS = ("random_group", "completeness", "rf_source_conformity_group", "evidence_rf_group")


def load(path):
    return json.loads(path.read_bytes())


def digest(path):
    sha256 = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            sha256.update(block)
    return sha256.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def check_bound_files(root, entries):
    seen = set()
    for entry in entries:
        name = entry["path"]
        path = (root / name).resolve()
        require(path.is_relative_to(root) and name not in seen, f"Invalid bound path {name}")
        require(digest(path) == entry["sha256"], f"Digest mismatch {name}")
        if "size_bytes" in entry:
            require(path.stat().st_size == entry["size_bytes"], f"Size mismatch {name}")
        seen.add(name)
    return seen


def prediction_metrics(expected, predictions):
    errors, labels = [], []
    for row, prediction in zip(expected, predictions, strict=True):
        key = ("id", "group", "y")
        require(all(row[k] == prediction[k] for k in key), f"Held-out row mismatch {row['id']}")
        residual = prediction["prediction"] - row["y"]
        require(math.isfinite(residual) and abs(residual) == prediction["absolute_error"],
                f"Saved absolute error mismatch {row['id']}")
        labels.append(row["y"])
        errors.append(residual)
    count = len(labels)
    center = math.fsum(labels) / count
    rss = math.fsum(e * e for e in errors)
    tss = math.fsum((y - center) ** 2 for y in labels)
    require(tss > 0, "EXT-03 holdout must contain varying temperatures")
    return {"loss": math.fsum(map(abs, errors)) / count, "rmse": math.sqrt(rss / count),
            "r2": 1 - rss / tss}


def check_metrics(computed, saved, context):
    for key, value in computed.items():
        require(math.isclose(value, saved[key], rel_tol=0, abs_tol=1e-9),
                f"{context}: inconsistent {key}")


def check_selections(out, data_dir, config, selections):
    selection_data = load(data_dir / config["selection_input"])
    rows = selection_data["rows"]
    d0 = selection_data["roles"]["D0"]
    pool = selection_data["roles"]["pool"]
    pool_set = set(pool)
    require(set(d0).isdisjoint(pool_set), "D0 and pool indices overlap")
    require(set(d0) | pool_set == set(range(len(rows))), "Selection input role coverage")
    pool_groups = {rows[i]["group"] for i in pool}
    require({rows[i]["group"] for i in d0}.isdisjoint(pool_groups), "D0 and pool groups overlap")

    references = load(data_dir / config["audit_reference"])["records"]
    audit = load(out / "AUDIT.json")["sample"]
    expected_reference = random.Random(config["seed"] + 160000).sample(pool, 256)
    require([r["index"] for r in references] == expected_reference, "Unexpected reference sample")
    states = Counter()
    for ref, actual in zip(references, audit, strict=True):
        index = ref["index"]
        row = rows[index]
        state = "VERIFIED" if (row["x"], row["y"]) == (ref["x"], ref["y"]) else "CONFLICT"
        require((actual["index"], actual["id"], actual["state"]) == (index, row["id"], state),
                f"Audit status mismatch {row['id']}")
        states[state] += 1
    states["UNKNOWN"] = len(pool) - len(references)

    detector = load(out / "RF_MODEL.json")
    count = min(len(d0), round(len(d0) * 256 / len(pool)))
    rng = random.Random(config["seed"] + 180000)
    samples = {kind: rng.sample(range(len(d0)), count)
               for kind in ("source", "label_changed", "feature_changed")}
    require(detector["calibration_sample_indices"] == samples and detector["calibration_rows"] == 3 * len(d0),
            "Detector calibration sample mismatch")
    params = detector["params"]
    require((params["n_estimators"], params["max_depth"], params["random_state"], params["n_jobs"])
            == (32, 3, config["seed"], 1), "Unexpected detector parameters")

    truth = load(data_dir / config["injection_truth"])["records"]
    truth_by_index = {row["index"]: row["kind"] for row in truth}
    require(len(truth_by_index) == len(truth), "Duplicate controlled modification")
    method_keys = {f"k{budget}__{method}" for budget in BUDGETS for method in METHODS}
    require(set(selections) == method_keys, "Incomplete choice matrix")
    counts = []
    for name, selected in selections.items():
        name_budget, method = name.split("__")
        budget = int(name_budget[1:])
        indices = selected["indices"]
        require(len(indices) == len(set(indices)) == budget and set(indices) <= pool_set,
                f"Unexpected budget or membership {name}")
        require(selected["ids"] == [rows[i]["id"] for i in indices], f"Selection IDs {name}")
        groups = {rows[i]["group"] for i in indices}
        if method.endswith("_group"):
            require(len(groups) == min(len(pool_groups), budget), f"Group coverage {name}")
        labels = sum(truth_by_index.get(i) == "label" for i in indices)
        features = sum(truth_by_index.get(i) == "feature" for i in indices)
        counts.append({"selection": name, "n": budget, "controlled_source_modifications": labels + features,
                       "label_modifications": labels, "feature_modifications": features})
    recorded = load(out / "QUALITY_POSTHOC.json")["selections"]
    require(recorded == counts, "Controlled modification counts differ from the frozen choices")
    return rows, d0, dict(states), counts


def check(run_dir, data_dir):
    run_dir, data_dir = run_dir.resolve(strict=True), data_dir.resolve(strict=True)
    config_path = data_dir / "config.json"
    config = load(config_path)
    seed = config["seed"]
    require(config["task_id"] == "EXT-03" and seed in {1103, 2207, 3301}, "Unexpected EXT-03 configuration")
    require(config["models"] == list(MODEL_NAMES) and config["budgets"] == list(BUDGETS), "Unfrozen matrix")
    manifest = load(run_dir / "RUN_MANIFEST.json")
    require((manifest["task_id"], manifest["seed"], manifest["run_id"]) == ("EXT-03", seed, run_dir.name),
            "Run identity mismatch")
    require((manifest["status"], manifest["verify_status"]) == ("COMPLETE", "REPRODUCED"), "Incomplete run")
    require(digest(config_path) == manifest["config_sha256"] == digest(run_dir / "CONFIG.json"),
            "Configuration digest binding")
    names = check_bound_files(run_dir, manifest["files"])
    actual = {p.relative_to(run_dir).as_posix() for p in run_dir.rglob("*") if p.is_file()}
    require(names == actual - {"RUN_MANIFEST.json"}, "Unexpected or unbound run file")
    freeze_path = run_dir / "CODE_FREEZE.json"
    freeze = load(freeze_path)
    require(digest(freeze_path) == manifest["freeze_sha256"], "Code freeze digest binding")
    require(freeze["git"]["git_commit"] == COMMIT and freeze["git"]["git_dirty"] is False, "Wrong execution commit")
    require(manifest["code"] == freeze["code"] and manifest["config_sha256"] == freeze["config_sha256"],
            "Code freeze identity")
    require(config["inputs"] == freeze["inputs"] == manifest["inputs"], "Input manifest binding")
    input_names = check_bound_files(data_dir, config["inputs"])

    monitor = load(run_dir / "COST.json")["monitor"]
    require(monitor["exit_code"] == 0 and monitor["training_go_sent"] and monitor["worker_started"],
            "Supervisor completion check")
    require(monitor["peak_rss_bytes"] <= 1610612736 and monitor["minimum_available_bytes"] >= 805306368
            and monitor["wall_seconds"] <= 300, "Supervisor resource boundary")
    out = run_dir / "worker_output"
    choices_path = out / "SELECTION_FREEZE.json"
    choices = load(choices_path)
    heldout_access = load(out / "HELDOUT_ACCESS.json")
    choice_sha = digest(choices_path)
    require(choices["config_sha256"] == manifest["config_sha256"], "Choice configuration binding")
    require(choice_sha == heldout_access["selection_sha256"]
            and choices["frozen_monotonic"] <= heldout_access["heldout_read_started_monotonic"],
            "Held-out ordering")
    require(all(choices[f"{key}_parsed_before_freeze"] is False
                for key in ("test_labels", "development_labels", "injection_truth")), "Early holdout parsing")
    selected = choices["methods"]
    rows, d0, states, controlled_counts = check_selections(out, data_dir, config, selected)
    holdout = {split: load(data_dir / config[key])["records"]
               for split, key in (("dev", "development_input"), ("test", "test_input"))}

    arms = [f"{model}__{name}" for model in MODEL_NAMES for name in ("D0", *selected)]
    plan = load(run_dir / "PLAN_STATUS.json")
    require(plan["expected"] == arms and plan["not_recorded"] == []
            and plan["recorded"] == [{"arm": arm, "status": "COMPLETE"} for arm in arms], "Plan status")
    summary = load(out / "SUMMARY.json")
    require(summary["status"] == "COMPLETE" and summary["seed"] == seed
            and summary["target_fit_attempts"] == 18 and summary["detector_fit_attempts"] == 1,
            "Unexpected fits or run summary status")
    require(summary["selection_sha256"] == choice_sha, "Run summary choices binding")
    auto = load(run_dir / "VERIFY_REPORT.json")
    require(auto["status"] == "REPRODUCED" and auto["seed"] == seed and auto["arms"] == len(arms),
            "Frozen verifier status")
    scores, observations = {}, 0
    for arm, from_summary in zip(arms, summary["methods"], strict=True):
        arm_dir = out / arm
        model, name = arm.split("__", 1)
        added = selected[name]["indices"] if name != "D0" else []
        indices = d0 + added
        members = load(arm_dir / "TRAIN_MEMBERS.json")
        records = [{key: rows[i][key] for key in ("id", "source_row", "group")} for i in indices]
        require(members == {"indices": indices, "members": records}, f"Actual train membership {arm}")
        metrics = load(arm_dir / "METRICS.json")
        require(from_summary == metrics and metrics["arm"] == arm and metrics["model"] == model
                and metrics["status"] == "COMPLETE", f"Run summary metrics differ {arm}")
        require(metrics["n_added"] == metrics["k"] == len(added) and metrics["n_train"] == len(indices)
                and metrics["selection_sha256"] == choice_sha, f"Budget or choice binding {arm}")
        scores[arm] = {}
        for split, expected in holdout.items():
            predictions = load(arm_dir / (split + "_PREDICTIONS.json"))
            require(metrics[split]["metric"] == "MAE" and metrics[split]["n"] == len(expected), f"Count {arm}/{split}")
            recomputed = prediction_metrics(expected, predictions)
            check_metrics(recomputed, metrics[split], f"Metrics {arm}/{split}")
            check_metrics(recomputed, auto["losses"][arm][split], f"Frozen verifier {arm}/{split}")
            scores[arm][split] = recomputed
            observations += len(expected)
    require(auto["prediction_rows"] == observations and auto["selectors_replayed"] == len(selected),
            "Frozen verifier observation count")

    contrasts = []
    for model in MODEL_NAMES:
        for budget in BUDGETS:
            losses = {method: scores[f"{model}__k{budget}__{method}"]["test"]["loss"] for method in METHODS}
            evidence = losses["evidence_rf_group"]
            contrasts.append({"model": model, "budget": budget,
                              "d0_mae_k": scores[f"{model}__D0"]["test"]["loss"], "test_mae_k": losses,
                              "source_conformity_minus_evidence_mae_k": losses["rf_source_conformity_group"] - evidence,
                              "random_minus_evidence_mae_k": losses["random_group"] - evidence})
    return {"status": "CHECKED", "experiment": "EXT-03", "seed": seed, "run_id": manifest["run_id"],
            "fixed_commit": COMMIT, "config_sha256": manifest["config_sha256"],
            "scope": "Checks saved predictions against independently checked held-out labels and selection artifacts.",
            "prediction_rows": observations, "selections_checked": len(selected), "completed_arms": len(arms),
            "run_files_checked": len(names), "input_files_checked": len(input_names),
            "audit_status_counts": states, "controlled_selection_counts": controlled_counts,
            "test_pairs": contrasts, "recalculated_metrics": scores}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    result = check(args.run, args.inputs)
    with args.report.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({key: result[key] for key in
                      ("status", "seed", "run_id", "completed_arms", "prediction_rows", "test_pairs")}))
