"""Independently replay the prepared EXT-03 inputs using the UCI release."""
import argparse
import csv
import hashlib
import io
import json
import random
import statistics
import zipfile
from collections import defaultdict
from decimal import Decimal
from pathlib import Path


SOURCE_ZIP = "87f4490d73390ff94ee01dbf0d7d32abc80b22f2c803d471765cfc46a9f6371e"
SOURCE_TRAIN = "4dfb6e3a1f6ffd969e5a5e42f093c4800d1e2a6c8b1e309f8fcd9f23d86952f3"
SOURCE_MATERIAL = "b68ae6b55ea8581eff8b1ffba073a899db7e2d2f7f3b781bb0802f643f51e5f7"
SHA = lambda b: hashlib.sha256(b).hexdigest()


def read_source(archive):
    assert SHA(archive.read_bytes()) == SOURCE_ZIP
    with zipfile.ZipFile(archive) as f:
        train, material = (f.read(next(n for n in f.namelist() if Path(n).name == key))
                           for key in ("train.csv", "unique_m.csv"))
    assert SHA(train) == SOURCE_TRAIN and SHA(material) == SOURCE_MATERIAL
    a = csv.reader(io.StringIO(train.decode("utf-8-sig")))
    b = csv.reader(io.StringIO(material.decode("utf-8-sig")))
    columns = next(a)
    assert columns[-1] == "critical_temp" and len(set(columns[:-1])) == 81
    assert next(b)[-2:] == ["critical_temp", "material"]
    formulas, vectors, values, temperatures = defaultdict(list), defaultdict(list), {}, {}
    for number, (s, m) in enumerate(zip(a, b, strict=True), 1):
        assert Decimal(s[-1]) == Decimal(m[-2])
        assert int(s[0]) == sum(Decimal(x) > 0 for x in m[:-2])
        formulas[m[-1].strip()].append(number)
        vectors[tuple(Decimal(x) for x in s[:-1])].append(number)
        values[number] = [float(x) for x in s[:-1]]
        temperatures[number] = float(s[-1])
    assert len(values) == 21263
    return columns[:-1], formulas, vectors, values, temperatures


def role_groups(formulas, vectors, n, seed):
    # An undirected graph with one star per equality class preserves connectivity.
    adjacency = defaultdict(list)
    for partition in (formulas, vectors):
        for block in partition.values():
            for i in block[1:]:
                adjacency[block[0]].append(i)
                adjacency[i].append(block[0])
    groups, seen = {}, set()
    for first in range(1, n + 1):
        if first in seen:
            continue
        todo, component = [first], []
        seen.add(first)
        while todo:
            i = todo.pop()
            component.append(i)
            for j in adjacency[i]:
                if j not in seen:
                    seen.add(j)
                    todo.append(j)
        key = ",".join(str(i) for i in sorted(component))
        groups[key] = component
    assert len(groups) == 15170
    order = sorted(groups, key=lambda k: (SHA(f"{SOURCE_TRAIN}:{seed}:{k}".encode()), k))
    cursor = 0
    roles = {}
    for label, lower in (("D0", 512), ("pool", 8192), ("dev", 1024), ("test", 2048), ("unassigned", n)):
        members = {}
        while len(members) < lower and cursor < len(order):
            key = order[cursor]
            members.update(dict.fromkeys(groups[key], key))
            cursor += 1
        roles[label] = members
    assert sum(map(len, roles.values())) == n
    return roles


def verify(archive, path):
    load = lambda name: json.loads((path / name).read_bytes())
    config = load("config.json")
    for record in config["inputs"]:
        assert SHA((path / record["path"]).read_bytes()) == record["sha256"]
    seed = config["seed"]
    assert config["task_id"] == "EXT-03" and seed in (1103, 2207, 3301)
    columns, formulas, vectors, x, y = read_source(archive)
    roles = role_groups(formulas, vectors, len(x), seed)
    members = load("MEMBERS.json")["roles"]
    for name, pairs in roles.items():
        assert members[name] == [dict(source_row=i, id=f"superconductivity:{i:05d}", group=pairs[i])
                                 for i in sorted(pairs)]
    chosen = load("selection_input.json")
    assert chosen["task"]["feature_names"] == columns
    ordered = sorted(roles["D0"].keys() | roles["pool"].keys())
    assert [row["source_row"] for row in chosen["rows"]] == ordered
    for name in ("D0", "pool"):
        assert [ordered[pos] for pos in chosen["roles"][name]] == sorted(roles[name])
    d0, pool = sorted(roles["D0"]), sorted(roles["pool"])
    refs = random.Random(seed + 160000).sample(pool, 256)
    actual_refs = load("audit_reference.json")["records"]
    assert len(actual_refs) == len(refs)
    for row, i in zip(actual_refs, refs, strict=True):
        assert ordered[row["index"]] == i and row["id"] == f"superconductivity:{i:05d}"
        assert (row["x"], row["y"]) == (x[i], y[i])
    modified = random.Random(seed + 170000).sample(pool, len(pool)//5)
    middle = len(modified)//2
    target_change = 2 * (statistics.pstdev(y[i] for i in d0) or 1)
    feature_value = max(x[i][0] for i in d0) + 3 * (statistics.pstdev(x[i][0] for i in d0) or 1)
    changed_y, changed_x = set(modified[:middle]), set(modified[middle:])
    truth = load("injection_truth.json")["records"]
    assert len(truth) == len(modified)
    for row, i in zip(truth, modified, strict=True):
        kind, original = ("label", y[i]) if i in changed_y else ("feature", x[i][0])
        assert (ordered[row["index"]], row["kind"], row["original"]) == (i, kind, original)
    for row, i in zip(chosen["rows"], ordered, strict=True):
        expected = x[i] if i not in changed_x else [feature_value] + x[i][1:]
        assert row["x"] == expected and row["y"] == (y[i]+target_change if i in changed_y else y[i])
        assert row["id"] == f"superconductivity:{i:05d}"
        assert row["group"] == (roles["D0"].get(i) or roles["pool"][i])
    for name, filename in (("dev", "development_input.json"), ("test", "test_input.json")):
        records = load(filename)["records"]
        for row, i in zip(records, sorted(roles[name]), strict=True):
            assert (row["source_row"], row["id"], row["group"]) == (i, f"superconductivity:{i:05d}", roles[name][i])
            assert (row["x"], row["y"]) == (x[i], y[i])
    return dict(status="CHECKED", source_sha256=SOURCE_ZIP, paired_source_rows=len(x),
                connected_components=15170, role_counts={k:len(v) for k,v in roles.items()},
                reference_rows=len(refs), modified_labels=middle, modified_features=len(modified)-middle,
                feature_columns=len(columns), seed=seed, config_sha256=SHA((path/"config.json").read_bytes()))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    result = json.dumps(verify(args.archive, args.inputs), indent=2) + "\n"
    args.report.write_text(result, encoding="utf-8")
    print(result, end="")
