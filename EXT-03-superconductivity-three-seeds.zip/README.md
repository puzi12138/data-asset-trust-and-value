# EXT-03 Superconductivity 三个种子

固定执行提交 cfd73d1e5c84351348062b5c0fe8e4d7beebfb53。1103、2207、3301 按工作单依次执行，使用同一累计预算账本。归档包括每轮的监督、独立输入核对与结果复算。

数据由 UCI 的 Kam Hamidieh 于 2018 年发布，采用 CC BY 4.0。临界温度单位为 K。划分以相同化学式或相同的 81 个原始特征构成连通组。受控修改只发生在候选池中。版本核验所用的参照来自修改前的同源数据。

all_conditions.csv 列出全部 54 个条件的运行状态及 MAE、RMSE、R²。primary_test_mae_pairs.csv 记录事先指定的来源符合性组减证据组测试 MAE，正值表示证据组的测试 MAE 较低。seed_run_index.csv 列出各轮运行编号。

[UCI 数据与许可](https://doi.org/10.24432/C53P47) · [实验工作单](https://github.com/puzi12138/data-asset-trust-and-value/issues/16) · [固定执行提交](https://github.com/puzi12138/data-asset-trust-and-value/pull/20#issuecomment-6993413444)

## 从归档复算

解压后在固定执行提交的仓库根目录运行第一条命令。另两条命令使用归档内的独立核验工具。将 <解压目录>、<官方ZIP>、<seed> 和 <run_id> 换成实际值，报告名使用新路径。

```text
python -B scripts/external_experiments/regression_verify.py --result <解压目录>/results/<run_id>/worker_output --config <解压目录>/inputs/seed<seed>/config.json --data-dir <解压目录>/inputs/seed<seed> --output replay-<seed>.json
python -B <解压目录>/checks/check_inputs.py --archive <官方ZIP> --inputs <解压目录>/inputs/seed<seed> --report source-check-<seed>.json
python -B <解压目录>/checks/check_results.py --run <解压目录>/results/<run_id> --inputs <解压目录>/inputs/seed<seed> --report result-check-<seed>.json
```
