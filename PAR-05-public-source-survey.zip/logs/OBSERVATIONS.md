# 已观察的异常和控制

- 归档 HEAD 返回 200，但缺少长度、ETag 和 Last-Modified。尝试对一份小归档请求单字节区间时，响应没有提供 Content-Range，查询在读数据前关闭。容量以正式目录的压缩字节估算为准，原档内容摘要为 `UNKNOWN_METADATA_ONLY`。
- 按数据名推断浓度扩展版归档地址曾返回 404。重新读取 UCI 页面，使用实际下载按钮中的归档名后 HEAD 返回 200。[修正后的正式地址](https://archive.ics.uci.edu/static/public/270/gas+sensor+array+drift+dataset+at+different+concentrations.zip)
- UCI 243 的结构计数字段给出 0 个特征，公开变量说明逐项列出 6 个输入和第 7 列目标。计划以该列说明为准，正式解析后核验。[Yacht 数据说明](../evidence/uci-243.json)
- Banknote 的公开说明区分了真币类与伪币类样本，数据页的变量表只写整数 `class`。0/1 的物理语义登记为 `UNKNOWN`。[Banknote 数据说明](../evidence/uci-267.json)
- Covertype 等既有扩展任务仍按原编号管理。UCI 224/270、单一电厂的五次重排与不同文件格式都用于核对来源去重。[来源对照](../SOURCE_INDEPENDENCE.md)
- Gas Sensor Array Drift 原版和扩展版页面的许可原文与使用限制并存，暂停纳入首批。Appliances Energy 和 Hydraulic Systems 预计最大压缩量超过 10 MiB，同样暂停。[许可核对](../LICENSES.md) · [逐源资源表](../RESOURCES.csv)
