# PAR-05 独立公开数据源调查

核对了 10 个独立候选来源的发布身份、许可、下载容量、目标语义和可用分组。7 个候选通过目录层面的许可与容量筛查。首批为 Parkinsons Telemonitoring、Energy Efficiency 和 Steel Plates Faults，依次提供可隔离参与者的回归、可隔离模拟几何的回归和数值多类分类。[完整可编辑候选表](CANDIDATE_SOURCES.csv) · [逐源角色与预算](PLAN.json)

| 顺位 | 处置 | 候选 | 目录压缩大小 | 依据 |
|---:|---|---|---:|---|
| 1 | 首批 | Parkinsons Telemonitoring | 0.279 MiB | 明确的主体编号可隔离 42 名参与者。目标是插值的临床运动评分 |
| 2 | 首批 | Energy Efficiency | 0.073 MiB | 12 种已知建筑几何可按特征恢复分组。用独立几何评估模拟供暖负荷 |
| 3 | 首批 | Steel Plates Faults | 0.096 MiB | 七类标签明确，提供数值多类分类。公开表可查精确输入组 |
| 4 | 备用 | Yacht Hydrodynamics | 0.011 MiB | 可按几何隔离船型，同一母型限制应用范围 |
| 5 | 备用 | Electrical Grid Stability Simulated Data | 2.306 MiB | 大于其余小样本模拟来源，采用固定拓扑下的二分类 |
| 6 | 备用 | Combined Cycle Power Plant | 3.505 MiB | 固定电厂的回归。五个表是同一批记录的重排 |
| 7 | 备用 | Banknote Authentication | 0.044 MiB | 数值二分类。暂按类代码评估，钞票主体分组待确认 |
| 8 | 许可待核 | Gas Sensor Array Drift at Different Concentrations | 9.650 MiB | 与 UCI 224 同源。许可标注与研究用途条款并存 |
| 9 | 容量待核 | Appliances Energy Prediction | 11.425 MiB | 归档超过 10 MiB。若另行核定容量，按时间组隔离 |
| 10 | 容量待核 | Condition monitoring of hydraulic systems | 73.053 MiB | 归档超过 10 MiB，还有逐周期多通道解包开销 |

大小来自正式页面的压缩字节估算。网络查询包含数据页、目录 API 和正式归档的 HTTP HEAD，数据归档载荷读取 0 字节，训练 0 次。原始归档的 SHA-256 均记 `UNKNOWN_METADATA_ONLY`。固定六源清单及每个候选证据文本已有本轮摘要。[资源估算](RESOURCES.csv) · [许可与引用](LICENSES.md) · [来源独立性](SOURCE_INDEPENDENCE.md)

后续划分先冻结四角色和组键，再访问开发及评估标签。流程统一检查重复键、来源参照及预处理拟合范围。逐源给出组可用数、基线和追加预算。气体扩展版的 404 已修正为数据页实际地址，保留许可冲突、目录字段差异、超容量及代码语义待核项。[协议草案](PROTOCOL.md) · [异常与控制记录](logs/OBSERVATIONS.md)

## 在 Windows 重查

已用 Windows 11 x64 和 Python 3.12.6 标准库执行资料调查与表格生成。下列第一条命令核对当前归档。对目录重新取证请指定新路径，公开页面和字节估算可能随时间变化。

```powershell
python -X utf8 -B verify_package.py
python -X utf8 -B snapshot.py --out evidence-new
python -X utf8 -B make_tables.py --root .
```

最后一条只重建两张 CSV，读取当前目录的归档证据与 `PLAN.json`。将改过的计划和新采集证据放在其各自工作副本，生成结果随时间戳另存。原执行模型和本项目已发布数据均保持各自冻结版本。[运行环境](evidence/ENVIRONMENT.json) · [元数据退出记录](logs/METADATA.log) · [制表日志](logs/TABLES.log) · [全部文件校验值](MANIFEST.sha256)
