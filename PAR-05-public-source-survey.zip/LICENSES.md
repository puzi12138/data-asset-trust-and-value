# 来源和许可核对

发布入口均为加州大学尔湾分校（UCI）机器学习库。每条证据保留出版者标注的名称、创建者、出版年、目录更新时间、DOI、下载按钮地址、目录压缩与解包字节估算，以及实际 HEAD 响应。许可原文和原始栏目摘录逐源记录在 `evidence/uci-*.json`，列与状态见候选表。[可编辑候选表](CANDIDATE_SOURCES.csv)

目录对这些数据页给出的许可原文为 “This dataset is licensed under a Creative Commons Attribution 4.0 International (CC BY 4.0) license.” 其中原／扩展版本气体传感器的详述另有 “The dataset can be used exclusively for research purposes. Commercial purposes are fully excluded.” 两条用语的适用范围需由发布者确认。两个版本保留为同源证据，浓度扩展版的有效许可记为 `UNKNOWN` 且暂停纳入后续准备首批。[CC BY 4.0 法律文本](https://creativecommons.org/licenses/by/4.0/legalcode) · [UCI 原版](https://archive.ics.uci.edu/dataset/224/gas+sensor+array+drift+dataset) · [浓度扩展版](https://archive.ics.uci.edu/dataset/270/gas+sensor+array+drift+at+different+concentrations)

后续可共享经确认的 CC BY 4.0 资料时，随附原题名、作者、官方 DOI 和许可链接，标注输入转换、分组和受控修改。目录的日期是该页面的更新时间。获取原包后另记精确字节、下载时间、压缩包与成员摘要及适配版本。在本轮预算内只查询目录、许可和归档 HEAD 元数据，未取得数据载荷。

Appliances Energy 的目录说明引用了来自第三方的气象表。归档因容量已暂停。若后续实施，拟使用研究原始室内温湿度和家电电表字段。采用额外气象字段前重新核对该第三方来源及共享权限。[数据说明](evidence/uci-374.json)
