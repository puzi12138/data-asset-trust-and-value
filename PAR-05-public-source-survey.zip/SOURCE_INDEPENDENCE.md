# 来源身份与既有研究的对照

固定清单来自工程修订 `fdd5c6a134745a66ae7a3876f300526b0f68a564`。它已为每个训练任务登记来源、正式文件和档案摘要。[固定六源清单](evidence/SOURCES-at-fixed-commit.json)

| 原任务 | 数据源 | UCI ID |
|---|---|---:|
| EXP-01 | Spambase | 94 |
| EXP-02 | Concrete Compressive Strength | 165 |
| EXP-03 | Wine | 109 |
| EXP-04 | Auto MPG | 9 |
| EXP-05 | Ionosphere | 52 |
| EXP-06 | Airfoil Self-Noise | 291 |

公开扩展任务已占用 Covertype、Letter Recognition、Superconductivity 和 Bike Sharing，继续沿各自工作单。另核对已有研究记录中的来源登记及本轮候选名称、产生机构和采集对象。十个候选未发现与这批既有材料同源或被用于调参的记录。候选逐项的状态为 `NOT_FOUND_IN_REVIEWED_RECORDS`，查询范围是当前可核对的项目记录。[Covertype](https://github.com/puzi12138/data-asset-trust-and-value/issues/14) · [Letter](https://github.com/puzi12138/data-asset-trust-and-value/issues/15) · [Superconductivity](https://github.com/puzi12138/data-asset-trust-and-value/issues/16) · [Bike Sharing](https://github.com/puzi12138/data-asset-trust-and-value/issues/17)

本轮按数据产生过程判断来源，保留原始项目、采集对象或模拟设计和官方 DOI。Energy Efficiency 来自建筑几何模拟，Parkinsons Telemonitoring 来自参与者的随访测量。它们有共同作者，研究任务与观测对象分别独立。Yacht Hydrodynamics 的船型来自同一母型，登记为一个水槽试验来源。Appliances Energy Prediction 来自单住宅实测，包含额外合并的公共气象记录。

Gas Sensor Array Drift 的原版（UCI 224）与浓度扩展版（UCI 270）使用同一批 13,910 个测量，扩展版额外给出浓度，只计一个来源。Combined Cycle Power Plant 的五次重排以及 XLSX 与 ODS 两种格式共享原始观测，未来选取一个工作表作为固定原始表。后续在下载授权和限额内取得原包，逐一核对官方 DOI、压缩包及表摘要、稳定原始行键、原始输入重复组或时间重叠。发现相同采集批次、母表衍生版或已参与调参的测试来源时暂停登记，交维护者决定用途。[浓度扩展说明](evidence/uci-270.json) · [原版记录](evidence/uci-224.json) · [电厂的五次重排](evidence/uci-294.json)
