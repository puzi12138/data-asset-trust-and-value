"""Generate the editable PAR-05 tables from the evidence and protocol."""

from argparse import ArgumentParser
import csv
from hashlib import sha256
import json
from pathlib import Path


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def build(root):
    plan = load(root / "PLAN.json")
    evidence = root / "evidence"
    archive_limit = plan["download_limit_bytes"]
    files = {(row["uci_id"]): evidence / f"uci-{row['uci_id']}.json" for row in plan["candidates"]}
    source_rows, resource_rows = [], []
    for row in plan["candidates"]:
        path = files[row["uci_id"]]
        meta = load(path)
        cite = meta["citation"]
        license_info = meta["license"]
        count = meta["catalogue_count"]
        estimate = meta["archive_bytes_catalogue_estimate"]
        source_rows.append({
            "rank": row["rank"], "status": row["status"], "uci_id": meta["dataset_id"],
            "title": meta["title"], "publisher": "University of California, Irvine Machine Learning Repository",
            "catalogue_url": meta["catalogue_url"], "official_archive_url": meta["archive_url"],
            "creators": " | ".join(cite["creators"]), "publication_year": cite["year"],
            "catalogue_update": cite["last_updated_catalogue"], "doi": cite["doi"],
            "archive_bytes_estimated": estimate, "archive_sha256": "UNKNOWN_METADATA_ONLY",
            "metadata_snapshot_sha256": sha256(path.read_bytes()).hexdigest(),
            "license_effective_status": "UNKNOWN" if license_info["additional_restriction_quote"] else "CC BY 4.0",
            "license_page_quote": license_info["page_text"], "license_legal_url": license_info["legal_code_url"],
            "license_additional_quote": license_info["additional_restriction_quote"] or "",
            "official_rows": count["rows"], "catalogue_feature_count": count["features"],
            "documented_feature_count": row["documented_features"], "analysis_feature_count_before_encoding": row["analysis_features"],
            "collection": row["collection"], "target": row["target"], "task": row["kind"],
            "split_group": row["group_rule"], "role_proposal": row["roles"], "retained_inputs": row["features"],
            "baseline_proposal": row["baseline"], "acquisition_budgets": "/".join(map(str, row["k"])),
            "missing_reported_by_catalogue": meta["declared_missing_values"], "quality_and_scope": row["quality"],
            "tuning_history_review": "NOT_FOUND_IN_REVIEWED_RECORDS",
            "source_evidence": f"evidence/{path.name}",
        })
        resource_rows.append({
            "uci_id": row["uci_id"], "title": meta["title"], "status": row["status"],
            "archive_bytes_catalogue_estimate": estimate,
            "archive_mib_catalogue_estimate": f"{estimate / 1048576:.3f}",
            "archive_limit_bytes": archive_limit,
            "archive_size_gate": "HOLD_SIZE" if estimate > archive_limit else "FITS_ESTIMATE",
            "catalogue_uncompressed_bytes_estimate": meta["uncompressed_bytes_catalogue_estimate"],
            "raw_numeric_array_mib_estimate": f"{count['rows'] * row['documented_features'] * 8 / 1048576:.3f}",
            "analysis_array_mib_before_encoding_estimate": f"{count['rows'] * row['analysis_features'] * 8 / 1048576:.3f}",
            "archive_head_http_status": meta["archive_head"]["status"],
            "archive_bytes_read": 0,
            "training_status": "NOT_RUN_PROTOCOL_ONLY",
        })
    return {"CANDIDATE_SOURCES.csv": source_rows, "RESOURCES.csv": resource_rows}


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    for name, rows in build(args.root).items():
        with (args.root / name).open("w", encoding="utf-8-sig", newline="") as file:
            writer = csv.DictWriter(file, fieldnames=list(rows[0]), lineterminator="\n")
            writer.writeheader()
            writer.writerows(rows)
        print(f"{name}: {len(rows)} rows")


if __name__ == "__main__":
    main()
