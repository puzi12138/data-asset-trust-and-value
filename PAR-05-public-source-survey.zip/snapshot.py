"""Collect UCI catalogue metadata and public experiment source pins for PAR-05."""

from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from hashlib import sha256
from html import unescape
import json
from pathlib import Path
import re
from urllib.error import HTTPError
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen


REPOSITORY = "https://api.github.com/repos/puzi12138/data-asset-trust-and-value"
PIN = "fdd5c6a134745a66ae7a3876f300526b0f68a564"
PIN_URL = (
    "https://raw.githubusercontent.com/puzi12138/data-asset-trust-and-value/"
    + PIN + "/experiments/community/data/SOURCES.json"
)
UCI = "https://archive.ics.uci.edu"
IDS = (242, 243, 198, 270, 471, 374, 189, 294, 267, 447)
COMPANION = 224
PAGE_LIMIT = 4 * 1024 * 1024
LICENSE_LINK = "https://creativecommons.org/licenses/by/4.0/legalcode"


def read_html(url, expected_host):
    request = Request(url, headers={"User-Agent": "PAR-05 public metadata audit"})
    with urlopen(request, timeout=30) as response:
        if urlparse(response.geturl()).netloc != expected_host:
            raise ValueError("Unexpected host after redirect: " + response.geturl())
        body = response.read(PAGE_LIMIT + 1)
        if len(body) > PAGE_LIMIT:
            raise ValueError("Metadata exceeded read limit: " + url)
    return body


def head_status(url):
    request = Request(url, method="HEAD", headers={"User-Agent": "PAR-05 public metadata audit"})
    try:
        with urlopen(request, timeout=30) as response:
            return {"status": response.status, "content_length": response.headers.get("Content-Length"),
                    "etag": response.headers.get("ETag"), "last_modified": response.headers.get("Last-Modified")}
    except HTTPError as error:
        return {"status": error.code, "content_length": None, "etag": None, "last_modified": None}


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def split_quote(text, length):
    # Preserve whole lines/paragraphs where available. Published source contacts are outside this projection.
    first = re.split(r"\r?\n\s*\r?\n", (text or "").strip(), maxsplit=1)[0]
    return " ".join(first.split())[:length]


def collect(number):
    endpoint = f"{UCI}/api/dataset?id={number}"
    raw_metadata = read_html(endpoint, urlparse(UCI).netloc)
    source = json.loads(raw_metadata)
    if source["status"] != 200 or source["data"]["uci_id"] != number:
        raise ValueError("UCI API did not return the requested dataset.")
    meta = source["data"]
    html = read_html(meta["repository_url"], urlparse(UCI).netloc)
    page = html.decode("utf-8")
    license_clause = re.search(r"<p[^>]*>(\s*This dataset is licensed under a.*?license\.)\s*</p>", page, re.S)
    if not license_clause or LICENSE_LINK not in license_clause.group(1):
        raise ValueError(f"UCI dataset {number} has no recognized page licence.")
    license_text = " ".join(unescape(re.sub(r"<[^>]*>", "", license_clause.group(1))).split())
    archive = re.search(fr'<a\b[^>]*href="(/static/public/{number}/[^"]+\.zip)"[^>]*\bdownload=', page)
    if not archive:
        raise ValueError(f"UCI dataset {number} has no official download button.")
    archive_url = urljoin(UCI, unescape(archive.group(1)))
    unescaped_payload = page.replace(r'\"', '"')
    compressed = re.search(r'"totalCompressedSize":"(\d+)"', unescaped_payload)
    uncompressed = re.search(r'"totalSize":"(\d+)"', unescaped_payload)
    if not compressed or not uncompressed:
        raise ValueError(f"UCI dataset {number} has no catalogue byte estimate.")
    contents = re.search(r'<th>File</th><th>Size</th></tr></thead>\s*<tbody>(.*?)</tbody>', page, re.S)
    listed_files = re.findall(r'<tr><td>([^<]+)</td><td>([^<]+)</td>', contents.group(1) if contents else "")
    citation = {
        "creators": meta.get("creators") or [],
        "year": meta.get("year_of_dataset_creation"),
        "last_updated_catalogue": meta.get("last_updated"),
        "doi": meta.get("dataset_doi"),
    }
    info = meta.get("additional_info") or {}
    summary = info.get("summary") or ""
    restrictions = re.search(r"The dataset can be used exclusively for research purposes\. Commercial purposes are fully excluded\.", summary)
    return {
        "dataset_id": number,
        "title": meta["name"].strip(),
        "catalogue_url": meta["repository_url"],
        "metadata_url": endpoint,
        "archive_url": archive_url,
        "archive_head": head_status(archive_url),
        "archive_bytes_catalogue_estimate": int(compressed.group(1)),
        "uncompressed_bytes_catalogue_estimate": int(uncompressed.group(1)),
        "files_as_displayed": listed_files,
        "citation": citation,
        "catalogue_count": {"rows": meta["num_instances"], "features": meta["num_features"]},
        "declared_missing_values": meta["has_missing_values"],
        "license": {"page_text": license_text, "legal_code_url": LICENSE_LINK,
                    "additional_restriction_quote": restrictions.group(0) if restrictions else None},
        "data_excerpt": split_quote(summary, 950),
        "variables_excerpt": " ".join((info.get("variable_info") or "").split())[:1400],
        "roles": {role: [{key: var[key] for key in ("name", "description", "units")} for var in meta["variables"]
                         if var["role"] == role] for role in ("ID", "Target")},
        "metadata_response_sha256": sha256(raw_metadata).hexdigest(),
        "page_response_sha256": sha256(html).hexdigest(),
    }


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    if any(args.out.iterdir()):
        raise ValueError("Use a new empty evidence directory.")
    pins = read_html(PIN_URL, "raw.githubusercontent.com")
    listed = json.loads(pins)
    if [d["task_id"] for d in listed["datasets"]] != [f"EXP-{i:02d}" for i in range(1, 7)]:
        raise ValueError("The fixed source list should identify the original six tasks.")
    (args.out / "SOURCES-at-fixed-commit.json").write_bytes(pins)
    with ThreadPoolExecutor(max_workers=4) as pool:
        candidates = list(pool.map(collect, (*IDS, COMPANION)))
    observed = {"observation_utc": datetime.now(timezone.utc).isoformat(), "fixed_commit": PIN,
                "fixed_pins_url": PIN_URL, "fixed_pins_sha256": sha256(pins).hexdigest(),
                "archive_requests": {"method": "HEAD", "payload_bytes_read": 0},
                "catalogue_candidates": len(IDS), "companion_releases": [COMPANION]}
    for item in candidates:
        write(args.out / f"uci-{item['dataset_id']}.json", item)
        print(f"UCI {item['dataset_id']} | HEAD {item['archive_head']['status']} | "
              f"estimated compressed bytes {item['archive_bytes_catalogue_estimate']:,} | "
              f"license restriction quote {'present' if item['license']['additional_restriction_quote'] else 'absent'}")
    write(args.out / "SNAPSHOT.json", observed)
    print(f"Public pinned sources: {len(listed['datasets'])}. Complete catalogue candidates: {len(IDS)}.")
    print("Dataset archive payload bytes read: 0.")


if __name__ == "__main__":
    main()
