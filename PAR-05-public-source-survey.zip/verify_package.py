"""Check the complete PAR-05 evidence set from a fresh extraction."""

from argparse import ArgumentParser
from collections import Counter
import csv
from hashlib import sha256
import json
from pathlib import Path, PurePosixPath
import re
from urllib.parse import urlparse

from make_tables import build, load


def verify_tree(root):
    index = root / "MANIFEST.sha256"
    manifest = {}
    for raw in index.read_text(encoding="utf-8").splitlines():
        value, name = raw.split("  ", 1)
        path = PurePosixPath(name)
        assert re.fullmatch(r"[a-f0-9]{64}", value)
        assert path.as_posix() == name and not path.is_absolute() and ".." not in path.parts
        assert name not in manifest
        manifest[name] = value
    all_names = {path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file()}
    assert set(manifest) == all_names - {"MANIFEST.sha256"}
    forbidden = re.compile(rb"(?:[A-Za-z]:[\\/](?:users|documents and settings)[\\/]|/home/[\w.-]+/|gh[pousr]_[\w]{15,}|github_pat_[\w]{15,}|-----BEGIN [A-Z ]*PRIVATE KEY-----)", re.I)
    for name, wanted in manifest.items():
        payload = (root / name).read_bytes()
        assert sha256(payload).hexdigest() == wanted, name
        assert forbidden.search(payload) is None, name
    return len(manifest)


def verify_candidate_rows(root):
    evidence = root / "evidence"
    plan = load(root / "PLAN.json")
    snapshot = load(evidence / "SNAPSHOT.json")
    assert snapshot["fixed_commit"] == "fdd5c6a134745a66ae7a3876f300526b0f68a564"
    pins_path = evidence / "SOURCES-at-fixed-commit.json"
    assert sha256(pins_path.read_bytes()).hexdigest() == snapshot["fixed_pins_sha256"]
    assert snapshot["archive_requests"] == {"method": "HEAD", "payload_bytes_read": 0}
    pins = load(pins_path)["datasets"]
    assert len(pins) == 6 and len({p["archive_sha256"] for p in pins}) == 6
    candidates = plan["candidates"]
    order = [row["uci_id"] for row in candidates]
    assert len(set(order)) == len(order) == snapshot["catalogue_candidates"] == 10
    assert set(order).isdisjoint(p["uci_id"] for p in pins)
    assert set(order).isdisjoint({31, 59, 464, 275})
    assert [row["rank"] for row in candidates] == list(range(1, 11))
    assert [row["uci_id"] for row in candidates if row["status"] == "FIRST_BATCH"] == plan["first_batch"]
    assert 2 <= len(plan["first_batch"]) <= 4
    assert len({load(evidence / f"uci-{i}.json")["citation"]["doi"] for i in order}) == len(order)

    for row in candidates:
        meta = load(evidence / f"uci-{row['uci_id']}.json")
        assert meta["dataset_id"] == row["uci_id"] and meta["catalogue_count"]["rows"] > 0
        assert meta["archive_head"]["status"] == 200 and urlparse(meta["archive_url"]).netloc == "archive.ics.uci.edu"
        assert meta["citation"]["last_updated_catalogue"]
        assert meta["license"]["page_text"].startswith("This dataset is licensed under a Creative Commons Attribution 4.0 International")
        assert (row["status"] == "HOLD_SIZE") == (meta["archive_bytes_catalogue_estimate"] > plan["download_limit_bytes"])
        assert (row["status"] == "HOLD_LICENSE") == bool(meta["license"]["additional_restriction_quote"])
        assert row["analysis_features"] > 0 and all(row[key] for key in ("group_rule", "roles", "features", "target", "baseline"))
    assert plan["companion_releases"] == [224] and 224 not in order
    assert "extension of the Gas Sensor Array Drift Dataset" in load(evidence / "uci-270.json")["data_excerpt"]
    assert load(evidence / "uci-224.json")["license"]["additional_restriction_quote"]
    assert "Froude" in load(evidence / "uci-243.json")["variables_excerpt"]
    assert "Residuary" in load(evidence / "uci-243.json")["variables_excerpt"]
    assert "shuffled five times" in load(evidence / "uci-294.json")["data_excerpt"]
    return order, Counter(row["status"] for row in candidates)


def verify_tables(root):
    tables = build(root)
    for name, expected in tables.items():
        with (root / name).open(encoding="utf-8-sig", newline="") as file:
            actual = list(csv.DictReader(file))
        assert actual == [{k: str(v) for k, v in row.items()} for row in expected], name
    return list(tables)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    inventory = verify_tree(args.root)
    order, statuses = verify_candidate_rows(args.root)
    tables = verify_tables(args.root)
    print(json.dumps({"status": "VERIFIED", "manifest_files": inventory, "candidate_count": len(order),
                      "eligible_candidates": statuses["FIRST_BATCH"] + statuses["RESERVE"],
                      "first_batch": order[:statuses["FIRST_BATCH"]],
                      "status_counts": dict(statuses), "matching_tables": tables,
                      "dataset_payload_bytes": 0, "training_runs": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
