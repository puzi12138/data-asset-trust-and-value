"""Check the archived EXT-04 preparation against the official hour.csv."""
from argparse import ArgumentParser
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import random
import statistics


FEATURES = "season yr mnth hr holiday weekday workingday weathersit temp atemp hum windspeed".split()
SOURCE_SHA = "e03de4ee4ef4dc376ac6e04bf829673c6269e8eba5c60fa121640fa2f829504f"


def verify(raw, prepared):
    expected = hashlib.sha256(raw.read_bytes()).hexdigest()
    assert expected == SOURCE_SHA, "unexpected official hour.csv digest"
    with raw.open(encoding="ascii", newline="") as file:
        upstream = list(csv.DictReader(file))
    assert len(upstream) == 17379

    def read(name):
        return json.loads((prepared / name).read_text(encoding="utf-8"))

    config = read("config.json")
    assert (config["task_id"], config["training"], config["models"], config["budgets"]) == (
        "EXT-04", "NOT_RUN", ["ridge", "random_forest"], [128, 512])
    seed = config["seed"]
    for info in config["inputs"]:
        assert hashlib.sha256((prepared / info["path"]).read_bytes()).hexdigest() == info["sha256"]
    metadata = read("source_record.json")
    assert metadata["raw_sha256"] == expected and metadata["raw_size_bytes"] == raw.stat().st_size
    ascending = sorted(set(r["dteday"] for r in upstream))
    usable = len(ascending) - 6
    counts = (20 * usable // 100, 2, 40 * usable // 100, 2, 15 * usable // 100, 2)
    roles = ["D0", "buffer", "pool", "buffer", "dev", "buffer"]
    day_role = {}
    cursor = 0
    for role, count in zip(roles, counts):
        day_role.update({day: role for day in ascending[cursor:cursor + count]})
        cursor += count
    day_role.update({day: "test" for day in ascending[cursor:]})
    original, members = {}, {role: [] for role in ("D0", "pool", "dev", "test", "buffer")}
    for line, r in enumerate(upstream, 1):
        day = r["dteday"]
        identity = f"{day}:{int(r['hr']):02d}"
        assert int(r["instant"]) == line and identity not in original
        info = {"id": identity, "source_row": line, "group": day}
        members[day_role[day]].append(info)
        x = [float(r[f]) for f in FEATURES]
        y = int(r["cnt"])
        assert y == int(r["casual"]) + int(r["registered"])
        original[identity] = {**info, "x": x, "y": y, "split_group": day, "record_identity": identity}
    read_members = read("MEMBERS.json")
    assert read_members["roles"] == members and read_members["seed"] == seed
    for role, file in (("dev", "development_input.json"), ("test", "test_input.json")):
        assert read(file)["records"] == [original[r["id"]] for r in members[role]]

    selection = read("selection_input.json")
    assert selection["task"]["feature_names"] == FEATURES
    rows, d0, pool = selection["rows"], selection["roles"]["D0"], selection["roles"]["pool"]
    assert [r["source_row"] for r in rows] == sorted(r["source_row"] for r in members["D0"] + members["pool"])
    assert [rows[i]["id"] for i in d0] == [r["id"] for r in members["D0"]]
    assert [rows[i]["id"] for i in pool] == [r["id"] for r in members["pool"]]
    references = read("audit_reference.json")["records"]
    assert [r["index"] for r in references] == random.Random(seed + 160000).sample(pool, 256)
    for rec in references:
        source = original[rows[rec["index"]]["id"]]
        assert rec["id"] == source["id"] and rec["x"] == source["x"] and rec["y"] == source["y"]
    modifications = read("injection_truth.json")["records"]
    assert [r["index"] for r in modifications] == random.Random(seed + 170000).sample(pool, len(pool) // 5)
    label_n = len(modifications) // 2
    correction_by_index = {}
    delta = 2 * (statistics.pstdev(original[rows[i]["id"]]["y"] for i in d0) or 1)
    temperatures = [original[rows[i]["id"]]["x"][8] for i in d0]
    extreme = max(temperatures) + 3 * (statistics.pstdev(temperatures) or 1)
    for j, rec in enumerate(modifications):
        i = rec["index"]
        source = original[rows[i]["id"]]
        if j < label_n:
            assert rec["kind"] == "label" and rec["original"] == source["y"]
            correction_by_index[i] = {**source, "y": source["y"] + delta}
        else:
            assert rec["kind"] == "feature" and rec["original"] == source["x"][8]
            x = source["x"].copy()
            x[8] = extreme
            correction_by_index[i] = {**source, "x": x}
    for i, row in enumerate(rows):
        assert row == correction_by_index.get(i, original[row["id"]])
    audit = Counter("VERIFIED" if r["index"] not in correction_by_index else "CONFLICT" for r in references)
    return {"status": "INPUT_VERIFIED", "training": "NOT_RUN", "seed": seed,
            "hourly_records": len(upstream), "distinct_days": len(ascending),
            "checked_input_hashes": len(config["inputs"]),
            "roles": {k: len(v) for k, v in members.items()},
            "audit": dict(audit), "unknown": len(pool) - len(references),
            "modifications": dict(Counter(r["kind"] for r in modifications))}


if __name__ == "__main__":
    p = ArgumentParser(description=__doc__)
    p.add_argument("--raw", required=True, type=Path)
    p.add_argument("--data-dir", required=True, type=Path)
    args = p.parse_args()
    print(json.dumps(verify(args.raw, args.data_dir), indent=2))
