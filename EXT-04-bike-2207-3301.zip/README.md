# EXT-04 Bike Sharing 续跑复现包

首轮验收后，用固定执行提交 `70319fa189f4b520613b33afbbd0f6f6894c9357` 顺序执行 2207、3301。两个新增种子的冻结输入和结果目录随包提供。三个种子的指标表、运行索引和同一累计账本在包内。1103 的运行文件及第一次依赖预检停止的回执另有公开归档。[首轮验收记录](https://github.com/puzi12138/data-asset-trust-and-value/issues/17#issuecomment-6992309448) · [首轮公开归档](https://raw.githubusercontent.com/puzi12138/data-asset-trust-and-value/6e0eccba32f9765bc6635410862b7f54e8adc134/EXT-04-bike-1103.zip)

2207 正常结束，并通过自动和独立复算。3301 的工作进程保存全部 18 个条件和总表，监督器随后报告 `AccessDenied`，未记录退出码。3301 的原回执保留 `FAILED_SUPERVISOR`，其 18 个条件和逐条预测通过独立复算，报告在 `checks/independent-3301.json`。

数据来自 UCI Bike Sharing 官方小时表，许可 CC BY 4.0。各输入目录的 `source_record.json` 提供署名、下载地址和摘要。所有种子的时间划分相同，三个角色边界各保留两个整日的缓冲，候选加入量为 128 或 512 个小时。评价使用同时已观测的天气。[选样方法、模型及信息口径](https://github.com/puzi12138/data-asset-trust-and-value/issues/17)

## 复算

检出上述固定提交后，用 Python 3.10 执行以下命令。根据包内的 `seed_run_index.csv` 填写实际种子和运行编号。

```text
python -B scripts/external_experiments/regression_verify.py --result <解压目录>/results/<运行编号>/worker_output --config <解压目录>/inputs/seed<种子>/config.json --data-dir <解压目录>/inputs/seed<种子> --output <新生成的报告>.json
```

从 UCI 官方 ZIP 取得 `hour.csv` 后，可以逐条复核输入和角色。

```text
python -B <解压目录>/checks/verify_bike_inputs.py --raw <hour.csv> --data-dir <解压目录>/inputs/seed<种子>
```
