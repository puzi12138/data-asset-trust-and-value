# EXT-04 Bike Sharing 1103

使用 UCI Bike Sharing 的官方 `hour.csv`，按日期隔离训练、候选、开发和测试，并在三个边界各留两个完整日期。来源页列 Hadi Fanaee-T 和 João Gama，引用 DOI 10.24432/C5W894，许可 CC BY 4.0。官方归档中的 `hour.csv` 为 1,156,736 字节，SHA-256 为 `e03de4ee4ef4dc376ac6e04bf829673c6269e8eba5c60fa121640fa2f829504f`。包内 `inputs/seed1103/source_record.json` 留存取得时间及摘要。[官方数据和许可](https://doi.org/10.24432/C5W894)

本种子的 18 个目标模型条件均已完成，124,524 条开发与测试预测通过自动及独立复算。测试 MAE 的主比较为来源符合性排序减去证据组。所有预定条件同时存入 `all_conditions.csv`。运行状态、首次放行前停止及账本分别见 `seed_run_index.csv` 和 `results/.community-budget.json`。

输入经过受控版本修改，模型使用当小时观测天气。首种子的结果待维护者验收。认领、代码审查版本和运行前环境排查均已公开留痕。[认领](https://github.com/puzi12138/data-asset-trust-and-value/issues/17#issuecomment-6991048256) · [适配 PR](https://github.com/puzi12138/data-asset-trust-and-value/pull/19) · [执行版本记录](https://github.com/puzi12138/data-asset-trust-and-value/pull/19#issuecomment-6991356895) · [启动记录](https://github.com/puzi12138/data-asset-trust-and-value/issues/17#issuecomment-6991395424)

## 复算

将 ZIP 解压到仓库以外。从公开仓库切换到维护者记录的候选提交 `70319fa189f4b520613b33afbbd0f6f6894c9357`。在仓库根使用教程的 Windows Python 3.10 x64 环境，运行以下复算入口。用本机解压目录替换 `<归档>`，并把 `--output` 指向新 JSON。复算直接根据保存模型重建逐条预测、选择名单和指标。

```text
python -B scripts/external_experiments/regression_verify.py --result <归档>/results/20261118T205623Z-91d188823b66/worker_output --config <归档>/inputs/seed1103/config.json --data-dir <归档>/inputs/seed1103 --output <新报告>.json
```

从 UCI 官方归档取得 `hour.csv` 后，可独立核对其全部 17,379 条成员，含角色、六个缓冲日、256 条核验参照和 1,386 条受控修改。

```text
python -B <归档>/checks/verify_bike_inputs.py --raw <hour.csv> --data-dir <归档>/inputs/seed1103
```
