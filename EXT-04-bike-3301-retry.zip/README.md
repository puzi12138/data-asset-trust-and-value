# EXT-04 Bike Sharing 3301 两次运行记录

本包保留种子 3301 的原始运行与一次受监督复跑。首次监督器报告 `FAILED_SUPERVISOR`，18 个模型条件全部写出并通过独立复算。复跑按原输入、冻结摘要和同一累计账本执行，监督器记录 `COMPLETE`、退出码 0，全部 18 个条件通过自动与独立复算。对比见 `checks/retry-comparison.json`，运行索引见 `seed_run_index.csv`。[复跑授权](https://github.com/puzi12138/data-asset-trust-and-value/issues/17#issuecomment-6992671997)

数据为 UCI Bike Sharing，采用 CC BY 4.0。原始文件摘要、下载地址和署名在 `inputs/seed3301/source_record.json`。三个种子的日期划分一致，核验样本、受控修改及随机过程按照各种子生成。[1103 结果](https://github.com/puzi12138/data-asset-trust-and-value/issues/17#issuecomment-6991566939) · [2207 和原 3301 结果](https://github.com/puzi12138/data-asset-trust-and-value/issues/17#issuecomment-6992614312)

检出固定提交 `70319fa189f4b520613b33afbbd0f6f6894c9357`，根据索引选择运行编号，重新生成一份模型复算报告。输出文件放在结果目录和输入目录以外。

```text
python -B scripts/external_experiments/regression_verify.py --result <解压目录>/results/<运行编号>/worker_output --config <解压目录>/inputs/seed3301/config.json --data-dir <解压目录>/inputs/seed3301 --output <新报告>.json
```

对照 UCI 官方 `hour.csv` 复核数据角色及受控修改。

```text
python -B <解压目录>/checks/verify_bike_inputs.py --raw <hour.csv> --data-dir <解压目录>/inputs/seed3301
```
