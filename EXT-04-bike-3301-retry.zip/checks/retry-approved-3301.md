## EXT-04 3301 一次复跑记录

维护者已授权按原口径复跑一次种子 3301，并保留原有运行记录。第一次 3301 运行的全部 18 个模型条件及预测已通过独立复算，Windows 监督器在结束阶段报 `AccessDenied`，原回执为 `FAILED_SUPERVISOR`。[第一次 3301 运行及复算](https://github.com/puzi12138/data-asset-trust-and-value/issues/17#issuecomment-6992614312)

复跑沿用固定提交 `70319fa189f4b520613b33afbbd0f6f6894c9357`、原输入与冻结摘要、同一 Windows 虚拟环境和累计账本。正常结束以监督器记录 `COMPLETE`、工作进程退出码 0、18 个预定条件齐全且自动复算为 `REPRODUCED` 为准。完成后另行复算，并与原 3301 对照选择成员、训练成员、逐条预测、MAE、RMSE 与 R²，各次开销单独记录。此次授权对应一次训练启动。
