"""Recalculate every recorded EXT-01 arm from stored probabilities and held-out labels."""
import argparse
import hashlib
import json
import math
import random
from pathlib import Path

import numpy as np


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def score(rows, expected):
    assert [(p['id'], p['group'], p['y']) for p in rows] == [(r['id'], r['group'], r['y']) for r in expected]
    labels = list('1234567')
    assert all(p['classes'] == labels for p in rows)
    y = np.array([labels.index(p['y']) for p in rows])
    pred = np.array([labels.index(p['prediction']) for p in rows])
    proba = np.array([p['probabilities'] for p in rows])
    assert np.all(np.isfinite(proba)) and np.all(proba > 0) and np.all(proba <= 1)
    assert np.allclose(proba.sum(axis=1), 1, rtol=0, atol=2e-15)
    assert np.array_equal(pred, proba.argmax(axis=1))
    losses = -np.log(proba[np.arange(len(rows)), y])
    assert np.allclose(losses, [p['loss'] for p in rows], rtol=0, atol=2e-13)
    confusion = np.bincount(7*y + pred, minlength=49).reshape(7, 7)
    total = confusion.sum(axis=0) + confusion.sum(axis=1)
    f1 = np.divide(2*confusion.diagonal(), total, out=np.zeros(7), where=total>0)
    return dict(loss=float(losses.mean()), accuracy=float(np.mean(y==pred)), macro_f1=float(f1.mean()))


def check(run, inputs, freeze):
    worker = run/'worker_output'
    cfg = read(inputs/'config.json')
    manifest = read(run/'RUN_MANIFEST.json')
    assert cfg['task_id'] == manifest['task_id'] == 'EXT-01'
    assert manifest['seed'] == cfg['seed'] and manifest['config_sha256'] == sha(inputs/'config.json')
    assert manifest['freeze_sha256'] == sha(freeze)
    for item in manifest['files']:
        file = (run/item['path']).resolve()
        assert file.is_relative_to(run.resolve()) and file.stat().st_size == item['size_bytes']
        assert sha(file) == item['sha256']
    assert read(freeze)['inputs'] == cfg['inputs']
    summary = read(worker/'SUMMARY.json')
    frozen = read(worker/'SELECTION_FREEZE.json')
    tracked = read(run/'PLAN_STATUS.json')
    assert summary['target_fit_attempts'] == 18 and summary['detector_fit_attempts'] == 1
    assert frozen['config_sha256'] == manifest['config_sha256']
    for stage in ('test_labels', 'development_labels', 'injection_truth'):
        assert frozen[stage+'_parsed_before_freeze'] is False
    access = read(worker/'HELDOUT_ACCESS.json')
    assert frozen['frozen_monotonic'] <= access['heldout_read_started_monotonic']
    assert access['selection_sha256'] == sha(worker/'SELECTION_FREEZE.json')
    methods = ['random_group','completeness','rf_source_conformity_group','evidence_rf_group']
    selection = read(inputs/'selection_input.json')
    d0,pool = (selection['roles'][k] for k in ('D0','pool'))
    valid = set(pool)
    for k in (128,512):
        for method in methods:
            chosen = frozen['methods'][f'k{k}__{method}']
            assert len(chosen['indices']) == len(set(chosen['indices'])) == k
            assert set(chosen['indices']) <= valid
            assert [selection['rows'][i]['id'] for i in chosen['indices']] == chosen['ids']
    rf = read(worker/'RF_MODEL.json')
    samples = rf['calibration_sample_indices']
    num = min(len(d0), round(len(d0)*256/len(pool)))
    rng = random.Random(cfg['seed']+180000)
    for kind in ('source','label_changed','feature_changed'):
        assert samples[kind] == rng.sample(range(len(d0)), num)
    assert (rf['params']['n_estimators'],rf['params']['max_depth'],rf['params']['random_state'],rf['params']['n_jobs']) == (32,3,cfg['seed'],1)
    heldout = {s:read(inputs/name)['records'] for s,name in [('dev','development_input.json'),('test','test_input.json')]}
    expected = [f'{model}__{arm}' for model in ('logistic','random_forest') for arm in ['D0']+[f'k{k}__{m}' for k in (128,512) for m in methods]]
    assert set(expected) == set(tracked['expected']) == {r['arm'] for r in tracked['recorded']}
    assert not tracked['not_recorded']
    states, test_metrics, observations = {}, {}, 0
    for arm in expected:
        directory = worker/arm
        metrics = read(directory/'METRICS.json')
        states[arm] = metrics['status']
        model, suffix = arm.split('__',1)
        added = [] if suffix == 'D0' else frozen['methods'][suffix]['indices']
        assert read(directory/'TRAIN_MEMBERS.json')['indices'] == d0 + added
        assert metrics['n_train'] == len(d0)+len(added)
        if metrics['status'] not in ('COMPLETE','FAILED_CONVERGENCE'):
            continue
        for split, truth in heldout.items():
            scores = score(read(directory/(split+'_PREDICTIONS.json')), truth)
            assert metrics[split]['n'] == len(truth)
            for key,value in scores.items():
                assert math.isclose(metrics[split][key], value, rel_tol=0, abs_tol=2e-13)
            observations += len(truth)
            if split == 'test':
                test_metrics[arm] = scores
    contrasts = {}
    for model in ('logistic','random_forest'):
        for k in (128,512):
            a,b = [f'{model}__k{k}__{x}' for x in methods[-2:]]
            if states[a] == states[b] == 'COMPLETE':
                contrasts[f'{model}__k{k}'] = test_metrics[a]['loss'] - test_metrics[b]['loss']
    return dict(status='CHECKED', seed=cfg['seed'], run_id=manifest['run_id'], worker_status=summary['status'],
                manifest_status=manifest['status'], framework_verification=manifest['verify_status'],
                predictions_checked=observations, selections_checked=8, calibration_samples_per_copy=num,
                arm_states=states, test_metrics=test_metrics, paired_test_logloss_base_minus_evidence=contrasts)


if __name__ == '__main__':
    args = argparse.ArgumentParser(description=__doc__)
    for name in ('run','inputs','freeze','report'):
        args.add_argument('--'+name, type=Path, required=True)
    a = args.parse_args()
    result = check(a.run, a.inputs, a.freeze)
    with a.report.open('x', encoding='utf-8') as out:
        json.dump(result,out,indent=2)
        out.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('arm_states','test_metrics')}))
