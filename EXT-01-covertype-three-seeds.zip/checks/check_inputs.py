"""Check EXT-01 prepared inputs directly against the UCI Covertype release."""
import argparse
import gzip
import hashlib
import json
import random
import statistics
import zipfile
from pathlib import Path

import numpy as np


ARCHIVE_SHA = '89a975c2457cd48e824238ae43c5a3cb762e42c4b4078d9b44a4514055105f6d'
RAW_SHA = '0a9371cef7c964b5475d6053cc3e0894a5aa6f65ad1ed3ecb01c45aa96217945'
RAW_ROWS = 581012
LABELS = list('1234567')
NAMES = ['D0', 'pool', 'dev', 'test', 'unassigned']


def stream_hash(file):
    digest = hashlib.sha256()
    for block in iter(lambda: file.read(1024 * 1024), b''):
        digest.update(block)
    return digest.hexdigest()


def file_hash(path):
    with path.open('rb') as file:
        return stream_hash(file)


def read_official(archive):
    assert file_hash(archive) == ARCHIVE_SHA
    with zipfile.ZipFile(archive) as release:
        assert hashlib.sha256(release.read('covtype.info')).hexdigest() == '15f192a8cbebbf26af940301727d1795b8ca92a80dc1cc6b3bdad2af9546bc35'
        with release.open('covtype.data.gz') as compressed, gzip.GzipFile(fileobj=compressed) as raw:
            assert stream_hash(raw) == RAW_SHA
        with release.open('covtype.data.gz') as compressed, gzip.GzipFile(fileobj=compressed) as raw:
            data = np.loadtxt(raw, delimiter=',', dtype=np.int32)
    assert data.shape == (RAW_ROWS, 55)
    labels, totals = np.unique(data[:, 54], return_counts=True)
    assert list(map(str, labels)) == LABELS
    assert totals.tolist() == [211840, 283301, 35754, 2747, 9493, 17367, 20510]
    # Rows of the contiguous, fixed-width array have an exact byte representation.
    features = np.ascontiguousarray(data[:, :54])
    keys = features.view(np.dtype((np.void, 54 * features.itemsize))).ravel()
    _, first, inverse, count = np.unique(keys, return_index=True, return_inverse=True, return_counts=True)
    mapping = first[inverse] + 1
    multi = {}
    for i in np.flatnonzero(count[inverse] > 1):
        multi.setdefault(int(mapping[i]), []).append(int(i) + 1)
    return data, first+1, mapping, multi


def partition(data, starts, multi, seed):
    keys = {i: ','.join(map(str, members)) for i, members in multi.items()}
    prefix = f'{RAW_SHA}:{seed}:'.encode('ascii')
    starts = starts.tolist()
    order = sorted(starts, key=lambda i: hashlib.sha256(prefix + keys.get(i, str(i)).encode('ascii')).digest())
    roles = np.full(len(data)+1, 4, dtype=np.uint8)
    missing = set(range(1, 8))
    counts = dict.fromkeys(NAMES, 0)
    for first in order:
        rows = multi.get(first, [first])
        classes = {int(data[n-1, 54]) for n in rows}
        if classes & missing:
            missing -= classes
            roles[rows] = 0
            counts['D0'] += len(rows)
            if not missing:
                break
    assert not missing
    current = 0
    targets = [512, 8192, 1024, 2048]
    for first in order:
        if current == len(targets):
            break
        if roles[first] == 0:
            continue
        rows = multi.get(first, [first])
        roles[rows] = current
        counts[NAMES[current]] += len(rows)
        if counts[NAMES[current]] >= targets[current]:
            current += 1
    assert current == 4 and counts['D0'] <= 768
    counts['unassigned'] = len(data) - sum(counts.values())
    return roles, counts, keys


def verify(inputs, official):
    data, first_rows, mapping, multi = official
    load = lambda name: json.loads((inputs / name).read_bytes())
    config = load('config.json')
    seed = config['seed']
    assert seed in (1103, 2207, 3301) and config['task_id'] == 'EXT-01'
    assert (config['task_type'], config['feature_count'], config['mutation_feature_index']) == ('classification', 54, 0)
    assert config['schema'] == 'external-experiment-v1'
    assert config['budgets'] == [128, 512] and config['models'] == ['logistic', 'random_forest']
    stems = ['selection_input', 'audit_reference', 'development_input', 'test_input', 'injection_truth']
    expected_files = {name+'.json' for name in stems + ['MEMBERS', 'source_record', 'preparation']}
    for stem in stems:
        assert config[stem] == stem+'.json'
    assert len(config['inputs']) == len(expected_files) and {item['path'] for item in config['inputs']} == expected_files
    for item in config['inputs']:
        assert file_hash(inputs / item['path']) == item['sha256']
    assert load('source_record.json')['raw_sha256'] == RAW_SHA
    roles, counts, group_keys = partition(data, first_rows, multi, seed)
    def identifier(i):
        return f'covertype:{i:06d}'
    def group(i):
        first = int(mapping[i-1])
        return group_keys.get(first, str(first))
    meta = load('MEMBERS.json')
    assert meta['seed'] == seed and meta['source_sha256'] == RAW_SHA
    assert set(meta['roles']) == set(NAMES)
    members = {}
    for code, name in enumerate(NAMES):
        expected = np.flatnonzero(roles[1:] == code)+1
        assert len(expected) == counts[name] == len(meta['roles'][name])
        for i, row in zip(expected.tolist(), meta['roles'][name], strict=True):
            assert (row['source_row'], row['id'], row['group']) == (i, identifier(i), group(i))
        if code < 4:
            members[name] = expected.tolist()
    reference_numbers = meta['reference_source_rows']
    del meta
    selection = load('selection_input.json')
    assert (selection['task']['type'], selection['task']['feature_count'], selection['task']['allowed_labels']) == ('classification',54,LABELS)
    assert set(selection['roles']) == {'D0', 'pool'}
    expected_rows = sorted(members['D0'] + members['pool'])
    assert [r['source_row'] for r in selection['rows']] == expected_rows
    for name in ['D0', 'pool']:
        assert [expected_rows[pos] for pos in selection['roles'][name]] == members[name]
    reference = random.Random(seed+160000).sample(members['pool'], 256)
    assert reference == reference_numbers
    def version(i):
        return data[i-1, :54].tolist(), str(data[i-1, 54])
    for i, row in zip(reference, load('audit_reference.json')['records'], strict=True):
        assert expected_rows[row['index']] == i and row['id'] == identifier(i)
        assert (row['x'], row['y']) == version(i)
    changed = random.Random(seed+170000).sample(members['pool'], counts['pool']//5)
    n = len(changed)//2
    y_changes, x_changes = set(changed[:n]), set(changed[n:])
    for i, t in zip(changed, load('injection_truth.json')['records'], strict=True):
        assert expected_rows[t['index']] == i and t['kind'] == ('label' if i in y_changes else 'feature')
        assert (t['original_x'], t['original_y']) == version(i)
    heights = [int(data[i-1, 0]) for i in members['D0']]
    extreme = max(heights) + 3*(statistics.pstdev(heights) or 1.)
    for name in NAMES[:4]:
        if name in ('dev', 'test'):
            rows = load('development_input.json' if name == 'dev' else 'test_input.json')['records']
        else:
            rows = (selection['rows'][pos] for pos in selection['roles'][name])
        for i, row in zip(members[name], rows, strict=True):
            x, y = version(i)
            if i in x_changes:
                x[0] = extreme
            if i in y_changes:
                y = LABELS[(LABELS.index(y)+1) % len(LABELS)]
            assert (row['source_row'], row['id'], row['group']) == (i, identifier(i), group(i))
            assert (row['x'],row['y']) == (x,y)
    return dict(status='CHECKED', seed=seed, release_sha256=ARCHIVE_SHA, raw_sha256=RAW_SHA,
                config_sha256=file_hash(inputs/'config.json'), source_rows=len(data), features=54, classes=LABELS,
                exact_feature_groups=len(first_rows), groups_with_multiple_rows=len(multi), role_counts=counts,
                checked_original_references=len(reference), modified_labels=n, modified_features=len(changed)-n)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    result = verify(args.inputs, read_official(args.archive))
    with args.report.open('x', encoding='utf8') as out:
        json.dump(result, out, indent=2)
        out.write('\n')
    print(json.dumps(result))
