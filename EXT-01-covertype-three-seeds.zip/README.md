# EXT-01 Covertype 三次运行与复算

固定执行提交 5d1f89ee8425c6bfb7597dd0a5ba698118057e23。全部输入、选择名单、逐条预测、模型参数、指标、成本和监督回执可由运行编号索引。三次使用同一累计账本。

| 种子 | 运行编号 | 监督状态 | 自动复算 |
|---|---|---|---|
| 1103 | 20261118T235430Z-0b1f1a8f85eb | COMPLETE | REPRODUCED |
| 2207 | 20261118T235826Z-70cee20844be | COMPLETE | REPRODUCED |
| 3301 | 20261118T235950Z-73814c10aacb | COMPLETE | REPRODUCED |

来源为 Blackard, J. (1998). Covertype [Dataset]. UCI Machine Learning Repository，CC BY 4.0。Copyright Jock A. Blackard and Colorado State University，沿用原 covtype.info 的声明。改编包括一基源行号、精确 54 维向量分组、整组划分及受控候选版本修改。分组基于完整特征向量的精确相等，三次划分来自同一数据来源。

all_conditions.csv 包含全部四种方法及 D0 基线的开发和测试指标。primary_test_log_loss_pairs.csv 的正差表示证据组的测试 LogLoss 较低。选择冻结后，训练进程才解析评估标签。独立输入核查直接对照 UCI 原始发布与准备文件。

[UCI 数据和归属](https://doi.org/10.24432/C50K5N) · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) · [工作单](https://github.com/puzi12138/data-asset-trust-and-value/issues/14) · [固定版本](https://github.com/puzi12138/data-asset-trust-and-value/pull/21#issuecomment-6995136554)

## 复算

从仓库检出固定提交，在仓库根目录运行下列命令。将 <归档>、<种子>、<运行编号> 替换为解包后的路径及 seed_run_index.csv 记录。

```text
python -B scripts/external_experiments/verify.py --result <归档>/results/<运行编号>/worker_output --config <归档>/inputs/seed<种子>/config.json --data-dir <归档>/inputs/seed<种子> --output replay-<种子>.json
python -B <归档>/checks/check_results.py --run <归档>/results/<运行编号> --inputs <归档>/inputs/seed<种子> --freeze <归档>/results/<运行编号>/CODE_FREEZE.json --report result-check-<种子>.json
python -B <归档>/checks/check_inputs.py --archive <UCI官方ZIP> --inputs <归档>/inputs/seed<种子> --report source-check-<种子>.json
```

官方归档的地址和摘要见各种子的 source_record.json。使用新的报告文件名，原验证回执保留在解包目录中。
