# PAR-06 多模型多预算协议交付

**协议草案、可编辑矩阵和只读核验已完成。** 根据原任务编号和可用记录容量，定下 Spambase 分类与 Concrete 回归两个来源。固定比较逻辑回归或岭回归与单线程小型随机森林，追加预算为 32、64 条。首轮种子 1103 的两来源合计 92 次计划目标拟合，含每模型的既有数据参照与完整训练参照。另四个来源与种子组合在首轮验收后考虑，三种子矩阵共 276 行。

| 交付 | 内容 |
|---|---|
| [PROTOCOL_DRAFT.md](PROTOCOL_DRAFT.md) | 固定来源、目标模型、预处理、选择策略、预算、主要指标、成功与停止规则 |
| [RUN_MATRIX.csv](generated/RUN_MATRIX.csv) | 276 个逐拟合条件，含 92 个首轮条件、共享选择标识、数据用量和冻结配置摘要 |
| [FROZEN_TASKS.csv](generated/FROZEN_TASKS.csv) | 原六任务三种子的模型、追加规模、指标、配额与资源门槛 |
| [COST_DEFINITION.md](COST_DEFINITION.md) | 评估开销与完整训练的配对口径、Data Shapley 信息和成本、共享计时及失败账本 |
| [RESOURCE_ESTIMATE.md](RESOURCE_ESTIMATE.md) | 以历史复算日志为依据排期，先执行每来源一个 worker；候选六次 worker 预留合计 1,110 秒 |
| [ENTRYPOINTS_AND_TESTS.md](ENTRYPOINTS_AND_TESTS.md) | 正式多模型执行器、独立验算和监督功能的开发与验收条件 |

## 实际核验

固定提交为 `fdd5c6a134745a66ae7a3876f300526b0f68a564`。Windows x64 与 Python 3.10.11 x64。原选样测试六项通过。重新从指定的 UCI ZIP 准备了两个来源、各三个种子的真实输入。六份只读运行预检均为 `DRY_RUN_READY`，逐文件核实的 36 个 SHA-256 一致。按角色重建组数并逐对检查组隔离。两个来源的每个种子均支持两个计划预算。

新目标模型状态为 `PLANNED_NOT_RUN`，本轮目标拟合数为 0。实际可用内存和依赖版本见 [ENVIRONMENT.json](logs/ENVIRONMENT.json)，退出码与六组状态见 [READONLY_STATUS.json](logs/READONLY_STATUS.json)。各次准备和预检原始结果在 `logs/`，准备回执中的本地目录用占位符替换。历史资源行来源于已验 SHA-256 的 PAR-04 提交附件。Concrete 历史投稿摘要的漏位见 [历史复算记录](https://github.com/puzi12138/data-asset-trust-and-value/issues/11#issuecomment-6913876367)，本轮独立下载与准备的固定摘要均相符。该历史例与本轮未执行的拟合状态均记入 [FAILURES_AND_COUNTEREXAMPLES.csv](FAILURES_AND_COUNTEREXAMPLES.csv)。

## 实际执行与重放

从源码仓库的邻目录执行，使用 Windows x64 的 Python 3.10 环境。以下 PowerShell 命令中的相对目录可按位置替换。用于本轮的依赖包清单保存在 [DEPENDENCY_WHEELS.json](DEPENDENCY_WHEELS.json)。准备程序从 UCI 提取原数据时校验冻结源摘要。

```powershell
git clone --no-tags --branch main --single-branch https://github.com/puzi12138/data-asset-trust-and-value.git frozen
git -C frozen switch --detach fdd5c6a134745a66ae7a3876f300526b0f68a564
py -3.10 -m venv env
& './env/Scripts/python.exe' -m pip install --disable-pip-version-check -r frozen/requirements-experiments.txt
& './code/run_readonly_checks.ps1' -Repository './frozen' -Python './env/Scripts/python.exe' -Output './readonly-replay'
curl.exe --fail --location --output PAR-04-input.zip https://github.com/user-attachments/files/34909507/PAR-04-20261116.zip
& './env/Scripts/python.exe' -B './code/build_protocol_tables.py' --repo './frozen' --read-only './readonly-replay' --historical './PAR-04-input.zip' --out './generated-replay'
```

两条脚本分别执行基线与数据预检、检查来源和文件哈希、生成表格。生成表格重放后七个文件逐字节一致。快照的即时可用内存随运行变化，固定输入和方案表不随其变化。原历史成本只用提取的资源行；当前压缩包提供生成后的可编辑证据表与重放脚本。
