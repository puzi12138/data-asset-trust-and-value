"""Prepare and validate the PAR-06 plan using frozen data receipts. No model work."""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import subprocess
from itertools import combinations
from pathlib import Path
from zipfile import ZipFile


COMMIT = "fdd5c6a134745a66ae7a3876f300526b0f68a564"
PAR04_SHA = "7ebec8b20eacb3462409d546d8fe944df0cce83d76b9816f7ccf85a80ec6b895"
SEEDS = (1103, 2207, 3301)
TABLE_ROOT = "experiments/community/configs"
ROLES = ("D0", "pool", "dev", "test")
PER_RUN_CAP = 180
RESERVATION_OVERHEAD = 5
TOTAL_LEDGER = 1800
MODELS = {
    "classification": ("LogisticRegression", "RandomForestClassifier"),
    "regression": ("Ridge", "RandomForestRegressor"),
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def csv_output(directory, name, rows):
    with (directory / name).open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def json_output(directory, name, value):
    with (directory / name).open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def git(repo, *args):
    return subprocess.run(
        ["git", "-C", str(repo), *args], check=True, capture_output=True, text=True
    ).stdout.strip()


def frozen_inventory(repo):
    sources = {
        entry["dataset"]: entry for entry in read_json(repo / "experiments/community/data/SOURCES.json")["datasets"]
    }
    inventory = []
    fpaths = []
    configs = {}
    for task_dir in sorted((repo / TABLE_ROOT).iterdir()):
        if not task_dir.is_dir() or not task_dir.name.startswith("EXP-0"):
            continue
        for seed in SEEDS:
            path = task_dir / f"{seed}.json"
            cfg = read_json(path)
            source = sources[cfg["dataset"]]
            count = {k: len(cfg["roles"][k]) for k in ROLES}
            require(
                sum(count.values()) == len(set().union(*(set(cfg["roles"][k]) for k in ROLES))),
                "Frozen role indexes overlap",
            )
            require(
                cfg["source_archive_sha256"] == source["archive_sha256"] and
                cfg["fixed_limits"] == {
                    "cpu_threads": 2, "gpu": False, "worker_seconds": 300,
                    "cumulative_worker_seconds": TOTAL_LEDGER,
                },
                "Unexpected frozen source or resource rule",
            )
            rel = path.relative_to(repo).as_posix()
            item = {
                "task_id": cfg["task_id"],
                "dataset": cfg["dataset"],
                "task_type": cfg["task_type"],
                "seed": seed,
                "k_original": cfg["k"],
                "original_model": cfg["target_model"],
                "original_model_parameters": json.dumps(cfg["model_parameters"], sort_keys=True),
                "primary_metric": cfg["primary_metric"],
                "n_features": source["features"],
                "n_D0": count["D0"], "n_pool": count["pool"],
                "n_dev": count["dev"], "n_test": count["test"],
                "original_target_fits": 1 + len(cfg["expected_methods"]),
                "original_detector_fits": 1,
                "original_shapley_permutations": cfg["permutation_count"],
                "max_numeric_threads": cfg["fixed_limits"]["cpu_threads"],
                "max_worker_seconds": cfg["fixed_limits"]["worker_seconds"],
                "max_process_tree_rss_gib": 1.5, "start_available_gib": 1.5, "runtime_available_gib": 0.75,
                "engine_commit": COMMIT, "config_path": rel, "config_sha256": digest(path),
                "source_sha256": source["archive_sha256"],
            }
            inventory.append(item)
            configs[(item["task_id"], seed)] = cfg
            fpaths.append({"path": rel, "sha256": item["config_sha256"]})
    require(len(inventory) == len(configs) == 18, "Expected all six tasks and three seeds")
    return inventory, configs, fpaths


def choose_sources(inventory):
    selected = {}
    for task in sorted({item["task_id"] for item in inventory}):
        splits = [item for item in inventory if item["task_id"] == task]
        if all(item["n_pool"] >= item["k_original"] >= 2 for item in splits):
            selected.setdefault(splits[0]["task_type"], task)
    require(selected == {"classification": "EXP-01", "regression": "EXP-02"}, "Source rule changed")
    return set(selected.values())


def verify_prepared(checks, selected, configs):
    receipts = read_json(checks / "logs/READONLY_STATUS.json")
    require(
        len(receipts) == 6 and {(r["task_id"], r["seed"]) for r in receipts} == {
            (task, seed) for task in selected for seed in SEEDS
        }, "Missing or duplicate data receipts",
    )
    files = []
    groups = {}
    for receipt in receipts:
        task, seed = receipt["task_id"], receipt["seed"]
        cfg = configs[(task, seed)]
        require(
            receipt["prepare_exit_code"] == receipt["preflight_exit_code"] == 0
            and receipt["preflight"] == "DRY_RUN_READY" and receipt["training_started"] is False,
            "A data check did not finish read-only",
        )
        for pin in cfg["inputs"]:
            actual_file = checks / "prepared" / pin["path"]
            require(digest(actual_file) == pin["sha256"], f"Input hash changed: {pin['path']}")
            files.append({"task_id": task, "seed": seed, "relative_path": pin["path"], "sha256": pin["sha256"]})
        members = read_json(checks / "prepared" / cfg["members"])["roles"]
        by_role = {}
        for role in ROLES:
            require([r["index"] for r in members[role]] == cfg["roles"][role], "Member order differs")
            by_role[role] = {r["group"] for r in members[role]}
        require(all(not (a & b) for a, b in combinations(by_role.values(), 2)), "Group overlap")
        groups[(task, seed)] = {role: len(values) for role, values in by_role.items()}
    require(len(files) == 36, "Expected 36 frozen input receipts")
    return files, groups


def historical_costs(archive, selected):
    require(digest(archive) == PAR04_SHA, "Historical attachment SHA differs")
    with ZipFile(archive) as bundle:
        with bundle.open("ALL_RUNS.csv") as handle:
            rows = csv.DictReader(io.TextIOWrapper(handle, encoding="utf-8-sig"))
            extracted = [
                {
                    "task_id": row["task_id"], "seed": int(row["seed"]),
                    "run_id": row["run_id"], "status": row["run_status"], "independent": row["verify_status"],
                    "original_k": int(row["k"]), "scope": row["intake_gate_status"],
                    "wall_seconds": round(float(row["run_total_wall_seconds"]), 6),
                    "cpu_seconds": round(float(row["run_total_cpu_seconds"]), 6),
                    "peak_rss_mib": round(int(row["run_peak_rss_bytes"]) / 2**20, 6),
                    "detector_seconds": round(float(row["rf_fit_predict_seconds"]), 6),
                    "shapley_seconds": round(float(row["shapley_all_compute_seconds"]), 6),
                }
                for row in rows
                if row["task_id"] in selected
            ]
    require(len(extracted) == 6 and all(r["status"] == "COMPLETE" and r["independent"] == "REPRODUCED" for r in extracted),
            "Historical resource references are incomplete")
    return extracted


def plan(inventory, selected, configs, groups, costs):
    arms, runs = [], []
    for item in inventory:
        task, seed = item["task_id"], item["seed"]
        if task not in selected:
            continue
        cfg = configs[(task, seed)]
        k = item["k_original"]
        phase = "PILOT" if seed == min(SEEDS) else "FOLLOWUP_HELD"
        metadata = {
            "task_id": task, "dataset": item["dataset"], "seed": seed, "phase": phase,
            "primary_metric": item["primary_metric"], "frozen_parent_config_sha256": item["config_sha256"],
        }
        require(item["n_pool"] >= k and groups[(task, seed)]["pool"] >= k, "Budget would exhaust pool or groups")
        methods = cfg["expected_methods"]
        conditions = [(0, "D0", "utility_reference"), (item["n_pool"], "FULL_TRAIN", "cost_denominator")]
        conditions.extend((b, m, "selection_comparison") for b in (k // 2, k) for m in methods)
        current = [
            {
                **metadata, "target_model": model, "k": b, "method": method, "purpose": purpose,
                "n_train": item["n_D0"] + b, "target_fits": 1,
                "selection_id": f"{task}/{seed}/{b}/{method}",
                "val_selector_extra_labels": method == "mc_data_shapley",
                "status": "PLANNED_NOT_RUN",
            }
            for model in MODELS[item["task_type"]]
            for b, method, purpose in conditions
        ]
        old = [r for r in costs if r["task_id"] == task]
        old_max = max(r["wall_seconds"] for r in old)
        ratio = len(current) / item["original_target_fits"]
        estimate = math.ceil(ratio * old_max)
        require(estimate < PER_RUN_CAP, "Historical wall envelope already exceeds proposed limit")
        worker = {
            **metadata,
            "k_levels": f"{k // 2},{k}", "pool_groups": groups[(task, seed)]["pool"],
            "target_fits": len(current), "shared_detector_fits": 1,
            "shared_shapley_permutations": cfg["permutation_count"],
            "shared_shapley_candidate_updates": cfg["permutation_count"] * item["n_pool"],
            "prediction_rows": len(current) * (item["n_dev"] + item["n_test"]),
            "historical_max_wall_seconds": old_max,
            "old_pipeline_copies_wall_proxy_seconds": estimate,
            "reserved_worker_cap_seconds": PER_RUN_CAP,
            "launch_ledger_reservation_seconds": PER_RUN_CAP + RESERVATION_OVERHEAD,
            "historical_max_rss_mib": max(r["peak_rss_mib"] for r in old),
            "one_dense_feature_copy_mib": round(
                (item["n_D0"] + item["n_pool"] + item["n_dev"] + item["n_test"]) * item["n_features"] * 8 / 2**20, 3
            ),
            "max_nodes_second_model_forest": 64 * (2**9 - 1),
            "rss_cap_gib": 1.5,
        }
        arms.extend(current)
        runs.append(worker)
    keys = {(a["task_id"], a["seed"], a["target_model"], a["k"], a["method"]) for a in arms}
    require(len(keys) == len(arms) == 276, "Planned conditions must each occur once")
    require(sum(a["phase"] == "PILOT" for a in arms) == 92, "Invalid pilot arm count")
    require(sum(r["launch_ledger_reservation_seconds"] for r in runs) < TOTAL_LEDGER, "Matrix exceeds ledger")
    return arms, runs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--read-only", type=Path, required=True)
    parser.add_argument("--historical", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    options = parser.parse_args()
    repo, checks, archive, out = options.repo, options.read_only, options.historical, options.out
    require(git(repo, "rev-parse", "HEAD") == COMMIT and not git(repo, "status", "--porcelain"), "Frozen checkout changed")
    require(read_json(checks / "logs/PAR-06-baseline-status.json")["exit_code"] == 0, "Baseline did not pass")
    inventory, configs, paths = frozen_inventory(repo)
    selected = choose_sources(inventory)
    pins, groups = verify_prepared(checks, selected, configs)
    timings = historical_costs(archive, selected)
    arms, runs = plan(inventory, selected, configs, groups, timings)
    more = (
        "experiments/community/data/SOURCES.json", "requirements-experiments.txt", "tests/test_dataset_selection.py",
        "scripts/experiments/prepare_data.py", "scripts/experiments/run_task.py", "scripts/experiments/worker.py",
        "scripts/experiments/check_env.py", "scripts/experiments/resources.py",
        "scripts/experiments/verify_result.py", "scripts/training/supervisor.py",
        "src/data_asset_poc/assessment/selection.py", "src/data_asset_poc/assessment/value_methods.py",
    )
    paths.extend({"path": rel, "sha256": digest(repo / rel)} for rel in more)
    out.mkdir(parents=True, exist_ok=False)
    csv_output(out, "FROZEN_TASKS.csv", inventory)
    csv_output(out, "RUN_MATRIX.csv", arms)
    csv_output(out, "RESOURCE_ESTIMATE.csv", runs)
    csv_output(out, "HISTORICAL_RESOURCE_ROWS.csv", timings)
    csv_output(out, "INPUT_HASHES.csv", pins)
    json_output(out, "FROZEN_MANIFEST.json", {"commit": COMMIT, "files": paths, "historical_attachment_sha256": PAR04_SHA})
    summary = {
        "status": "PROTOCOL_DRAFT_READONLY_CHECKS_PASSED",
        "model_training_started": False,
        "new_target_fits": 0,
        "baseline_tests_passed": 6,
        "reconstructed_frozen_splits": len(runs),
        "prepared_files_verified": len(pins),
        "pilot_runs": 2,
        "pilot_target_fits_planned": 92,
        "held_runs": 4,
        "held_target_fits_planned": 184,
        "total_target_fits_planned": len(arms),
        "all_runs_reservation_ceiling_seconds": sum(x["launch_ledger_reservation_seconds"] for x in runs),
        "ledger_limit_seconds": TOTAL_LEDGER,
    }
    json_output(out, "TABLE_CHECK.json", summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
