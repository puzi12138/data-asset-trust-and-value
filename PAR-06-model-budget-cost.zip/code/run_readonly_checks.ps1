param(
    [Parameter(Mandatory)][string]$Repository,
    [Parameter(Mandatory)][string]$Python,
    [Parameter(Mandatory)][string]$Output
)

$ErrorActionPreference = 'Stop'
$repo = (Resolve-Path -LiteralPath $Repository).Path
$interpreter = (Resolve-Path -LiteralPath $Python).Path
$root = [IO.Path]::GetFullPath($Output)
if ($root.StartsWith($repo + '\', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Output must be outside the frozen repository.'
}
if (Test-Path -LiteralPath $root) { throw 'Use a new output directory.' }
$null = New-Item -Path $root -ItemType Directory
$logs = Join-Path $root 'logs'
$cache = Join-Path $root 'cache'
$null = New-Item -Path $logs -ItemType Directory
$null = New-Item -Path $cache -ItemType Directory
$fixed = 'fdd5c6a134745a66ae7a3876f300526b0f68a564'

function Save-Json($value, [string]$file) {
    $value | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $file -Encoding utf8NoBOM
}

function Verify-Checkout {
    $head = git rev-parse HEAD
    if ($LASTEXITCODE -ne 0 -or $head -ne $fixed) { throw 'Wrong revision.' }
    $changed = git status --porcelain
    if ($LASTEXITCODE -ne 0 -or $changed) { throw 'Frozen checkout is dirty.' }
}

function Run-Json([string[]]$pythonArgs, [string]$logName) {
    $lines = @(& $interpreter @pythonArgs 2>&1)
    $code = $LASTEXITCODE
    $text = $lines -join [Environment]::NewLine
    # The upstream prepare report includes the absolute output directory.
    # Retain the full event fields and replace local roots before publication.
    $text = $text.Replace($root.Replace('\', '\\'), '<CHECK_OUTPUT>')
    $text = $text.Replace($root, '<CHECK_OUTPUT>').Replace($repo, '<FROZEN_REPO>')
    $slug = Join-Path $logs $logName
    $text | Set-Content -LiteralPath $slug -Encoding utf8NoBOM
    if ($code -ne 0) { throw "Check failed with exit code $code. See $logName." }
    return ($text | ConvertFrom-Json)
}

Push-Location $repo
try {
    Verify-Checkout
    $env:PYTHONPATH = Join-Path $repo 'src'
    $env:PYTHONIOENCODING = 'utf-8'
    $env:PYTHONDONTWRITEBYTECODE = '1'
    $baselineLog = Join-Path $logs 'PAR-06-baseline.log'
    $baseline = @(& $interpreter -B -m unittest -v tests.test_dataset_selection 2>&1)
    $baselineCode = $LASTEXITCODE
    $baseline | Set-Content -LiteralPath $baselineLog -Encoding utf8NoBOM
    Save-Json ([pscustomobject]@{ exit_code=$baselineCode; suite='tests.test_dataset_selection'; training='NOT_RUN' }) (Join-Path $logs 'PAR-06-baseline-status.json')
    if ($baselineCode -ne 0) { throw 'Frozen selection baseline failed.' }
    $snapshot = Run-Json @('-B','-u','scripts/experiments/check_env.py') 'ENVIRONMENT.json'
    if ($snapshot.python_version -notlike '3.10.*' -or $snapshot.architecture -ne 'AMD64' -or $snapshot.os -ne 'Windows') {
        throw 'Expected Windows x64 and Python 3.10.'
    }
    $sources = (Get-Content -LiteralPath 'experiments/community/data/SOURCES.json' -Raw -Encoding UTF8 | ConvertFrom-Json).datasets
    foreach ($name in @('spambase','concrete')) {
        $source = $sources | Where-Object { $_.dataset -eq $name }
        $archive = Join-Path $cache ($name + '.zip')
        curl.exe --fail --location --silent --show-error --retry 2 --output $archive $source.archive_url
        if ($LASTEXITCODE -ne 0) { throw "Download failed for $name." }
        if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne $source.archive_sha256) {
            throw "Source SHA-256 differs for $name."
        }
    }
    $statuses = foreach ($task in @('EXP-01','EXP-02')) {
        foreach ($seed in @(1103,2207,3301)) {
            $idText = [string]$seed
            $stage = "$task-$seed"
            $data = Join-Path $root 'prepared'
            $prep = Run-Json @('-B','-u','scripts/experiments/prepare_data.py','--task-id',$task,'--seed',$idText,'--output',$data,'--cache',$cache) "$stage-prepare.json"
            $check = Run-Json @('-B','-u','scripts/experiments/run_task.py','--task-id',$task,'--seed',$idText,'--data-dir',$data,'--output',(Join-Path $root 'would-run'),'--dry-run','--max-workers','1','--timeout','180','--device','cpu') "$stage-preflight.json"
            if ($prep.status -ne 'PREPARED' -or $prep.training -ne 'NOT_RUN' -or
                $check.status -ne 'DRY_RUN_READY' -or -not $check.input_hashes_verified -or $check.training_started) {
                throw 'A frozen input check failed or unexpectedly entered training.'
            }
            [pscustomobject]@{ task_id=$task; seed=$seed; prepared_files=$prep.files; prepare_exit_code=0; preflight_exit_code=0; preflight=$check.status; training_started=$check.training_started }
        }
    }
    Verify-Checkout
    if (Test-Path -LiteralPath (Join-Path $root 'would-run')) { throw 'A dry run wrote a training directory.' }
    Save-Json @($statuses) (Join-Path $logs 'READONLY_STATUS.json')
} finally {
    Pop-Location
}
