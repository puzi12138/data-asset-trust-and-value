# EXT-03 Superconductivity 1103

运行编号 20261118T222502Z-4ffbfee7f8c6，监督回执 COMPLETE，自动复算 REPRODUCED，独立复算 REPRODUCED。

实验使用固定提交 cfd73d1e5c84351348062b5c0fe8e4d7beebfb53。UCI 数据由 Kam Hamidieh 提供（2018 年，CC BY 4.0）。目标是材料临界温度，单位为 K。按同一化学式或同一原始 81 维特征的连通组划分。两份 CSV 的作者生成代码、许可、来源和摘要记录在 inputs/seed1103/source_record.json。

all_conditions.csv 含每个已记录的条件和运行状态。primary_test_mae_pairs.csv 的正值表示证据组的测试 MAE 较低，负值表示来源符合性排序的测试 MAE 较低。两个追加预算、两种模型的所有条件随包提供。

[UCI 数据与许可](https://doi.org/10.24432/C53P47) · [实验工作单](https://github.com/puzi12138/data-asset-trust-and-value/issues/16) · [固定版本记录](https://github.com/puzi12138/data-asset-trust-and-value/pull/20#issuecomment-6993413444)

## 从归档复算

解压完整 ZIP，从固定提交的仓库根目录运行以下命令。将 <解压目录> 替换为实际路径，使用新的报告文件名。

```text
python -B scripts/external_experiments/regression_verify.py --result <解压目录>/results/20261118T222502Z-4ffbfee7f8c6/worker_output --config <解压目录>/inputs/seed1103/config.json --data-dir <解压目录>/inputs/seed1103 --output replay-1103.json
```

从 UCI 取得官方 ZIP 后，可独立核对逐行配对、分组和所有准备输入。

```text
python -B <解压目录>/checks/verify_inputs.py --archive <官方ZIP> --inputs <解压目录>/inputs/seed1103 --report source-check-1103.json
```
